<template>
 <div>
<h1>首页</h1>
 </div>
</template>

<script>
export default {
 data() {
 return {

 };
 },
};
</script>

<style lang="" scoped>

</style>
